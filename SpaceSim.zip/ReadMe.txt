Controls:

W/S: Thrust
A/D: Yaw
Mouse: Pitch and Roll
Left Click: Shoot
Home: Station
End: Space


Note: VERY work in progress, there is no use for credits and you cant die...

Plans: Enemies, a physical station that you have to dock to, upgrades/different weapons in the station to buy, projectile weapons.